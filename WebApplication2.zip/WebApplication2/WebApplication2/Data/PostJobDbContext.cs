﻿using Microsoft.EntityFrameworkCore;
using WebApplication2.Models;

namespace WebApplication2.Data
{
    public class PostJobDbcontext: DbContext
    {
        public PostJobDbcontext(DbContextOptions <PostJobDbcontext> options):base(options) 
        {
            
        }
        public DbSet<Postjob>Posts { get; set; }
    }
}
