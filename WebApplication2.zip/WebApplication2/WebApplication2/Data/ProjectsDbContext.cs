﻿using Microsoft.EntityFrameworkCore;
using WebApplication2.Models;

namespace WebApplication2.Data
{
    public class ProjectsDbContext:DbContext
    {
        public ProjectsDbContext(DbContextOptions<ProjectsDbContext> options) : base(options) 
        {
            
        }
        public DbSet<Project>Projects { get; set; }
        public DbSet<Studentprofile> Studentprofiles { get; set; }
    }
}
