﻿using Microsoft.EntityFrameworkCore;
using WebApplication2.Models;

namespace WebApplication2.Data
{
    public class ComapanyProjectDbContext : DbContext
    {
        public ComapanyProjectDbContext(DbContextOptions<ComapanyProjectDbContext> options) : base(options)
        {

        }
        public DbSet<CompanyProject> companyProjects { get; set; }
    }
}
