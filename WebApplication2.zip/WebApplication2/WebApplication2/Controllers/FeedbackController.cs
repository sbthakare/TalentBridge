﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using MySql.Data.MySqlClient;
using JobPostAPI.Models;
using System.Threading.Tasks;
using JobPostAPI.Models;

namespace JobPostAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FeedbackController : ControllerBase
    {
        private readonly string _connectionString = "Server=localhost;Database=feedback_db;User=root;Password=yourpassword;";

        // POST api/feedback/submit
        [HttpPost("submit")]
        public async Task<IActionResult> SubmitFeedback([FromForm] Feedback feedback)
        {
            // Get the username from session (ensure user is logged in)
            var username = HttpContext.Session.GetString("Username");

            if (string.IsNullOrEmpty(username))
            {
                return Unauthorized(new { Message = "User not logged in" });
            }

            // Ensure the feedback includes the username from session
            feedback.Username = username;

            // Save feedback into MySQL
            using (var connection = new MySqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                var query = "INSERT INTO feedbacks (Category, Rating, Comments, Username) VALUES (@Category, @Rating, @Comments, @Username)";
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Category", feedback.Category);
                    command.Parameters.AddWithValue("@Rating", feedback.Rating);
                    command.Parameters.AddWithValue("@Comments", feedback.Comments);
                    command.Parameters.AddWithValue("@Username", feedback.Username);

                    var result = await command.ExecuteNonQueryAsync();

                    if (result > 0)
                    {
                        return Ok(new { Message = "Feedback submitted successfully!" });
                    }
                    else
                    {
                        return StatusCode(500, new { Message = "Error while submitting feedback." });
                    }
                }
            }
        }
    }
}
