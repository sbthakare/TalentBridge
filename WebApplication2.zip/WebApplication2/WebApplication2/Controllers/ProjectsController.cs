﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Route("api/projects")]
    [ApiController]
    [EnableCors("AllowAll")]
    public class ProjectsController : ControllerBase
    {
        private static List<Project> Projects = new List<Project>();

        [HttpGet]
        public IActionResult GetProjects()
        {
            return Ok(Projects);
        }

        [HttpPost("/Submit")]
        public IActionResult AddProject([FromBody] Project project)
        {
            project.Id = Projects.Count + 1;
            Projects.Add(project);
            return CreatedAtAction(nameof(GetProjects), new { id = project.Id }, project);
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteProject(int id)
        {
            var project = Projects.FirstOrDefault(p => p.Id == id);
            if (project == null) return NotFound();
            Projects.Remove(project);
            return NoContent();
        }

    }
}
