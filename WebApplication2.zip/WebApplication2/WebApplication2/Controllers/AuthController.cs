﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Data;
using WebApplication2.Helpers;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Route("api/auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly ProjectDbContext _projectDbContext;
        private readonly JwtHelper _jwtHelper;

        public AuthController(ProjectDbContext projectDbContext, JwtHelper jwtHelper)
        {
            _projectDbContext = projectDbContext;
            _jwtHelper = jwtHelper;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] Register register)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var emailExists = await _projectDbContext.Users.AnyAsync(u => u.Email == register.Email);
            if (emailExists)
                return BadRequest(new { message = "Email already exists." });

            if (register.Role.Equals("admin", StringComparison.OrdinalIgnoreCase))
                return BadRequest(new { message = "Admin registration is not allowed." });

            var newUser = new User
            {
                FirstName = register.FirstName,
                LastName = register.LastName,
                Address = register.Address,
                PhoneNumber = register.PhoneNumber,
                Email = register.Email,
                UserName = register.UserName,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(register.Password),
                Role = register.Role
            };

            _projectDbContext.Users.Add(newUser);
            await _projectDbContext.SaveChangesAsync();
            return Ok(new { message = "Registration successful." });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] Login login)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var user = await _projectDbContext.Users.FirstOrDefaultAsync(u => u.UserName == login.UserName);
            if (user == null || !BCrypt.Net.BCrypt.Verify(login.Password, user.PasswordHash))
                return Unauthorized(new { message = "Invalid credentials." });

            var token = _jwtHelper.GenerateToken(user);
            return Ok(new { message = "Login successful", token, role = user.Role });
        }

        [HttpPost("forgot-password")]
        public async Task<IActionResult> ForgotPassword([FromBody] ForgotPassword forgotPassword)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var user = await _projectDbContext.Users.FirstOrDefaultAsync(u => u.Email == forgotPassword.Email);
            if (user == null)
                return NotFound(new { message = "User not found." });

            if (user.Role == "Admin")
                return BadRequest(new { message = "Admin password cannot be reset through this API." });

            user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(forgotPassword.NewPassword);
            await _projectDbContext.SaveChangesAsync();

            return Ok(new { message = "Password updated successfully." });
        }

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteUser(int id)
        {
            var user = await _projectDbContext.Users.FindAsync(id);
            if (user == null)
                return NotFound(new { message = "User not found." });

            _projectDbContext.Users.Remove(user);
            await _projectDbContext.SaveChangesAsync();

            return Ok(new { message = "User deleted successfully." });
        }

        [HttpGet("get/{username}")]
        public async Task<IActionResult> GetUserByUserName(string username)
        {
            var user = await _projectDbContext.Users
                .Where(u => u.UserName.ToLower() == username.ToLower())
                .Select(u => new
                {
                    u.Id,
                    u.FirstName,
                    u.LastName,
                    u.Address,
                    u.PhoneNumber,
                    u.Email,
                    u.UserName,
                    u.Role
                })
                .FirstOrDefaultAsync();

            if (user == null)
                return NotFound(new { message = "User not found." });

            return Ok(user);
        }

        [HttpGet("check-email")]
        public async Task<IActionResult> CheckEmailExists([FromQuery] string email)
        {
            bool exists = await _projectDbContext.Users.AnyAsync(u => u.Email == email);
            return Ok(new { exists });
        }
    }
}
