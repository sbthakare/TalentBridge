﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly EmployeeDbContext employeeDbContext;

        public EmployeeController(EmployeeDbContext employeeDbContext)
        {
            this.employeeDbContext = employeeDbContext;
        }

        [HttpPost]
        public async Task<IActionResult> CreateEmployee([FromBody] Employee employee)
        {
            if (employee == null)
            {
                return BadRequest("Invalid Employee");
            }
            await employeeDbContext.Employees.AddAsync(employee);
            await employeeDbContext.SaveChangesAsync();

            return Ok(new {Messgae="Your Employee Created Successfully"});
        }

        [HttpGet]
        [Route("/Employess")]
        public async Task<IActionResult> AlEmployee()
        {
            return Ok(await employeeDbContext.Employees.ToListAsync());
        }

        [HttpGet]
        [Route("/EmployeeId")]

        public async Task<IActionResult> getByid([FromRoute] int id)
        {
            Employee foundemployee=await employeeDbContext.Employees.FindAsync(id);

            if (foundemployee == null) { 
                    return NotFound();
            }
            return Ok(foundemployee);
        }

        [HttpPut]
        [Route("/Employeeupdate/{id}")]
        public async Task<IActionResult> update([FromRoute] int id, Employee updateemployee)
        {
            Employee foundid = await employeeDbContext.Employees.FindAsync(id);
            if (foundid != null)
            {
                foundid.Name = updateemployee.Name;
                foundid.Designation = updateemployee.Designation;
                foundid.Joiningdate = updateemployee.Joiningdate;
                foundid.Email = updateemployee.Email;
                foundid.Username = updateemployee.Username;
                foundid.Password = updateemployee.Password;

                await employeeDbContext.SaveChangesAsync();
                return Ok(foundid);
            }
            return NotFound();
        }

        [HttpDelete]
        [Route("/EmployeeDelete/{id}")]

        public async Task<IActionResult> deleteById([FromRoute] int id)
        {
            Employee foundid = await employeeDbContext.Employees.FindAsync(id);
            if (foundid != null) { 
                    employeeDbContext.Remove(foundid);
                await employeeDbContext.SaveChangesAsync();
                return Ok(foundid);
            }
            return NotFound();
        }
    }
}

