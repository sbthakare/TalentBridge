﻿using WebApplication2.Data;
using WebApplication2.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using WebApplication2.Data;

[Route("api/[controller]")]
[ApiController]
public class AdminAccountController : ControllerBase
{
    private readonly ProjectDbContext _context;

    public AdminAccountController(ProjectDbContext context)
    {
        _context = context;
    }

    // POST: api/AdminAccount/Login
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] AdminLoginRequest adminloginRequest)
    {
        if (adminloginRequest == null || string.IsNullOrEmpty(adminloginRequest.Username) || string.IsNullOrEmpty(adminloginRequest.Password))
        {
            return BadRequest("Invalid input.");
        }

        var adminUser = await _context.AdminUsers
            .Where(u => u.Username == adminloginRequest.Username)
            .FirstOrDefaultAsync();

        if (adminUser == null)
        {
            return NotFound("Admin user not found. Please register.");
        }

        if (adminUser.Password != adminloginRequest.Password)  // In production, use hashed passwords
        {
            return Unauthorized("Invalid password.");
        }

        if (adminUser.Role != "Admin")  // Ensure the user is an admin
        {
            return Unauthorized("You are not authorized to login as an Admin.");
        }

        return Ok(new { message = "Admin login successful!" });
    }

    // POST: api/AdminAccount/Register
    [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] AdminRegisterRequest adminregisterRequest)
    {
        if (adminregisterRequest == null || string.IsNullOrEmpty(adminregisterRequest.Username) || string.IsNullOrEmpty(adminregisterRequest.Password))
        {
            return BadRequest("Invalid input.");
        }

        // Check if the admin user already exists
        var existingAdminUser = await _context.AdminUsers
            .Where(u => u.Username == adminregisterRequest.Username)
            .FirstOrDefaultAsync();

        if (existingAdminUser != null)
        {
            return Conflict("Username already exists.");
        }

        // Create a new admin user
        var newAdminUser = new AdminUser
        {
            Username = adminregisterRequest.Username,
            Password = adminregisterRequest.Password,  // In production, hash the password
            Role = "Admin"  // Set the role explicitly to "Admin"
        };

        _context.AdminUsers.Add(newAdminUser);
        await _context.SaveChangesAsync();

        return Ok("Admin user registered successfully.");
    }
}

// LoginRequest and RegisterRequest for Admin

public class AdminLoginRequest
{
    public string Username { get; set; }
    public string Password { get; set; }
    public string Role { get; set; }  // This can be used for validating if it's an "Admin"
}

public class AdminRegisterRequest
{
    public string Username { get; set; }
    public string Password { get; set; }
    public string Role { get; set; }  // This can also be used to check if it's "Admin" in the registration phase
}

// Models (assuming you have these in your Data/Models folder)
public class AdminUser
{
    public int Id { get; set; }
    public string Username { get; set; }
    public string Password { get; set; }
    public string Role { get; set; }  // Admin role will be "Admin"
}

