﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostJobController : ControllerBase
    {
        private readonly PostJobDbcontext _postjobdbcontext;

        public PostJobController(PostJobDbcontext postjobdbcontext)
        {
            this._postjobdbcontext = postjobdbcontext;
        }
        [HttpPost]
        public async Task<IActionResult> CreateJob([FromBody] Postjob postjob)
        {
            if (postjob == null)
            {
                return BadRequest("Sorry");
            }
            await _postjobdbcontext.Posts.AddAsync(postjob);
            await _postjobdbcontext.SaveChangesAsync();
            return Ok(postjob);
        }

        [HttpGet]
        [Route("/Jobs")]

        public async Task<ActionResult<IEnumerable<Postjob>>> GetJob()
        {
            return await _postjobdbcontext.Posts.ToListAsync();
        }

        [HttpGet]
        [Route("/{id}")]

        public async Task<IActionResult> getJobsById([FromRoute] int id)
        {
            try
            {
                Postjob postjob = await _postjobdbcontext.Posts.FindAsync(id);
                if (postjob == null)
                {
                    return NotFound();
                }
                else
                {
                    return Ok(postjob);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
