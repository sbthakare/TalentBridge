﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Data;
using WebApplication2.Models;
using System.Threading.Tasks;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("AllowAll")] // Enable CORS globally
    public class ClientController : ControllerBase
    {
        private readonly ClientDbContext clientDbContext;

        public ClientController(ClientDbContext clientDbContext)
        {
            this.clientDbContext = clientDbContext;
        }

        // POST: api/Client
        [HttpPost]
        public async Task<IActionResult> ClientProject([FromBody] Clientproject clientproject)
        {
            if (clientproject == null)
            {
                return BadRequest("Invalid Project");
            }

            await clientDbContext.clientprojects.AddAsync(clientproject);
            await clientDbContext.SaveChangesAsync();
            return Ok(new { message = "Your Project Registered Successfully" });
        }

        // GET: api/Client/Projects
        [HttpGet("Projects")]
        public async Task<IActionResult> allProjects()
        {
            return Ok(await clientDbContext.clientprojects.ToListAsync());
        }

        // GET: api/Client/5
        [HttpGet("{id}")]
        public async Task<IActionResult> getById([FromRoute] int id)
        {
            var foundProject = await clientDbContext.clientprojects.FindAsync(id);

            if (foundProject == null)
            {
                return NotFound();
            }
            return Ok(foundProject);
        }

        // PUT: api/Client/5
        [HttpPut("{id}")]
        public async Task<IActionResult> update([FromRoute] int id, [FromBody] Clientproject updateclientproject)
        {
            var foundProject = await clientDbContext.clientprojects.FindAsync(id);
            if (foundProject != null)
            {
                foundProject.title = updateclientproject.title;
                foundProject.purpose = updateclientproject.purpose;
                foundProject.deadline = updateclientproject.deadline;
                foundProject.description = updateclientproject.description;
                foundProject.features = updateclientproject.features;

                await clientDbContext.SaveChangesAsync();
                return Ok(foundProject);
            }
            return NotFound();
        }
    }
}
