﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : Controller
    {
        private readonly AdminDbContext adminDbContext;

        public AdminController(AdminDbContext adminDbContext)
        {
            this.adminDbContext = adminDbContext;
        }

        [HttpPost]
        public async Task<IActionResult> CreateUser([FromBody] Admin admin)
        {
            if (admin == null)
            {
                return BadRequest("Invalid user data.");
            }

            await adminDbContext.admins.AddAsync(admin);
            await adminDbContext.SaveChangesAsync();

            return Ok(new { Message = "User created successfully!" });
        }

        [HttpGet]
        [Route("/Users")]
        public async Task<ActionResult<IEnumerable<Admin>>> GetUser()
        {
            return await adminDbContext.admins.ToListAsync();
        }

        //[HttpGet]
        //[Route("/addAdmin")]
        //public async Task<IActionResult> allAdmin()
        //{
        //    return Ok(await adminDbContext.admins.ToListAsync());
        //}

        //[HttpGet]
        //[Route("/Admin")]
        //public async Task<IActionResult> getByid([FromRoute] int id)
        //{
        //    Admin foundadmin=await adminDbContext.admins.FindAsync(id);
        //    if (foundadmin == null)
        //    {
        //        return NotFound();
        //    }
        //    return Ok(foundadmin);
        //}

        //[HttpPut]
        //[Route("/Adminupdate/{id}")]

        //public async Task<IActionResult> update([FromRoute]int id, Admin updateadmin )
        //{
        //    Admin foundId = await adminDbContext.admins.FindAsync(id);
        //    if (foundId != null) {
        //                 foundId.Username = updateadmin.Username;
        //        foundId.Password = updateadmin.Password;
        //        foundId.Email = updateadmin.Email;
        //        await adminDbContext.SaveChangesAsync();
        //        return Ok(foundId);
        //    }
        //    return NotFound();

        //}

        //[HttpDelete]
        //[Route("/Admindelete/{id}")]

        //public async Task<IActionResult> deleteByid([FromRoute] int id)
        //{
        //    Admin foundId = await adminDbContext.admins.FindAsync(id);    
        //    if(foundId != null)
        //    {
        //        adminDbContext.Remove(foundId);
        //        await adminDbContext.SaveChangesAsync();
        //        return Ok(foundId);
        //    }
        //    return NotFound();
        //}

    }
}
