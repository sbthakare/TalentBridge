﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentProfileController : ControllerBase
    {
        private readonly ProjectDbContext _projectDbContext;
        private readonly IWebHostEnvironment _environment;

        public StudentProfileController(ProjectDbContext projectDbContext, IWebHostEnvironment environment)
        {
            _projectDbContext = projectDbContext;
            _environment = environment;
        }
        [HttpPost("create")]
        public async Task<IActionResult> CreateProfile([FromBody] Studentprofile user)
        {
            if (user == null)
                return BadRequest("Invalid request data.");

            // Check if the username already exists
            if (await _projectDbContext.studentprofiles.AnyAsync(u => u.Username == user.Username))
                return Conflict("Username already exists.");

            await _projectDbContext.studentprofiles.AddAsync(user);
            await _projectDbContext.SaveChangesAsync();

            return CreatedAtAction(nameof(GetProfile), new { username = user.Username }, user);
        }
        [HttpGet("get/{username}")]
        public async Task<IActionResult> GetProfile(string username)
        {
            var user = await _projectDbContext.studentprofiles.FirstOrDefaultAsync(u => u.Username == username);
            if (user == null)
                return NotFound("User not found");

            return Ok(user);
        }
        [HttpPut("update")]
        public async Task<IActionResult> UpdateStudentProfile([FromBody] Studentprofile user)
        {
            if (user == null || string.IsNullOrEmpty(user.Username))
                return BadRequest("Invalid request data.");

            var existingUser = await _projectDbContext.studentprofiles.FirstOrDefaultAsync(u => u.Username == user.Username);
            if (existingUser == null)
                return NotFound("User not found");

            // Update user properties
            existingUser.FirstName = user.FirstName;
            existingUser.LastName = user.LastName;
            existingUser.Place = user.Place;
            existingUser.Dob = user.Dob;
            existingUser.Gender = user.Gender;
            existingUser.EducationStream = user.EducationStream;
            existingUser.EducationInstitute = user.EducationInstitute;
            existingUser.ProjectTitle = user.ProjectTitle;
            existingUser.ProjectPlatform = user.ProjectPlatform;
            existingUser.ProjectLink = user.ProjectLink;
            existingUser.Skill = user.Skill;

            _projectDbContext.studentprofiles.Update(existingUser);
            await _projectDbContext.SaveChangesAsync();

            return Ok(new { Message = "Profile updated successfully!" });
        }
        [HttpDelete("delete/{username}")]
        public async Task<IActionResult> DeleteProfile(string username)
        {
            var user = await _projectDbContext.studentprofiles.FirstOrDefaultAsync(u => u.Username == username);
            if (user == null)
                return NotFound("User not found");

            _projectDbContext.studentprofiles.Remove(user);
            await _projectDbContext.SaveChangesAsync();

            return Ok(new { Message = "User deleted successfully." });
        }
        [HttpPost("uploadResume")]
        public async Task<IActionResult> UploadResume([FromForm] IFormFile resume, [FromForm] string username)
        {
            var user = await _projectDbContext.studentprofiles.FirstOrDefaultAsync(u => u.Username == username);
            if (user == null)
                return NotFound("User not found");

            if (resume == null || resume.Length == 0)
                return BadRequest("No file uploaded.");

            var uploadsPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "resumes");

            if (!Directory.Exists(uploadsPath))
                Directory.CreateDirectory(uploadsPath);

            var fileExtension = Path.GetExtension(resume.FileName);
            if (fileExtension.ToLower() != ".pdf")
                return BadRequest("Only PDF files are allowed.");

            var fileName = $"{username}_{Guid.NewGuid()}{fileExtension}";
            var filePath = Path.Combine(uploadsPath, fileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await resume.CopyToAsync(stream);
            }

            user.ResumePath = $"/resumes/{fileName}";
            _projectDbContext.studentprofiles.Update(user);
            await _projectDbContext.SaveChangesAsync();

            return Ok(new { Message = "Resume uploaded successfully!", FilePath = user.ResumePath });
        }
    }
}
