﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompanyProjectController : ControllerBase
    {
        private readonly ComapanyProjectDbContext comapanyProjectDbContext;

        public CompanyProjectController(ComapanyProjectDbContext context)
        {
            this.comapanyProjectDbContext = context;
        }
        [HttpPost]
        public async Task<IActionResult> PostProject([FromBody] CompanyProject companyProject)
        {
            if (companyProject == null)
            {
                return BadRequest("Sorry");
            }
            await comapanyProjectDbContext.companyProjects.AddAsync(companyProject);
            await comapanyProjectDbContext.SaveChangesAsync();
            return Ok(companyProject);
        }

        [HttpGet]
        [Route("/CompanyProject")]

        public async Task<ActionResult<IEnumerable<CompanyProject>>> GetCompanyProject()
        {
            return await comapanyProjectDbContext.companyProjects.ToListAsync();
        }


    }
}
