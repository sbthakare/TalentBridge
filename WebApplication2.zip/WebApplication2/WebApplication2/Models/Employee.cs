﻿using System.ComponentModel.DataAnnotations;
using Microsoft.VisualBasic;

namespace WebApplication2.Models
{
    public class Employee
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }

        public string Designation {  get; set; }

        public DateTime Joiningdate { get; set; }
        public string Email {  get; set; }

        public string Username { get; set; }
        public string Password { get; set; }

    }
}
