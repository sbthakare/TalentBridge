﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication2.Models
{
    [Table("Postjob")]
    public class Postjob
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Title { get; set; }
        public decimal Salary { get; set; }
        public string JobType { get; set; }
        public int NoOfPositions { get; set; }
        public string JobDescription { get; set; }
        public DateTime PostedDate { get; set; }
        public DateTime ApplyBeforeDate { get; set; }
    }
}
