﻿using System;
using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Models
{
    public class Studentprofile
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Username { get; set; }

        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }

        public string Place { get; set; }
        public DateTime? Dob { get; set; }
        public string Gender { get; set; }
        public string EducationStream { get; set; }
        public string EducationInstitute { get; set; }
        public string ProjectTitle { get; set; }
        public string ProjectPlatform { get; set; }
        public string ProjectLink { get; set; }
        public string Skill { get; set; }
        public string? ResumePath { get; set; }  // Store resume file path
    }
}
