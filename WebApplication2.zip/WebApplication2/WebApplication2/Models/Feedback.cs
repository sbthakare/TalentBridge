﻿namespace JobPostAPI.Models
{
    
        public class Feedback
        {
            public int Id { get; set; }
            public string Category { get; set; }
            public int Rating { get; set; }
            public string Comments { get; set; }
            public string Username { get; set; }  // This will be from session
        }
    

}
