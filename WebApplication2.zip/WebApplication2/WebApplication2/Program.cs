using Microsoft.EntityFrameworkCore;
using WebApplication2.Data;
using WebApplication2.Helpers;

var builder = WebApplication.CreateBuilder(args);


var MyAllowSpecificOrigins = "_myAllowSpecificOrigins";

builder.Services.AddCors(options =>
{
    options.AddPolicy(MyAllowSpecificOrigins,
        policy =>
        {
            policy.WithOrigins("http://localhost:3000")
                  .AllowAnyHeader()
                  .AllowAnyMethod();
        });
});



// Add services to the container
builder.Services.AddControllers();

string conString = builder.Configuration.GetConnectionString("ConStr");
builder.Services.AddDbContext<AdminDbContext>(op => op.UseMySql(conString, ServerVersion.AutoDetect(conString)));
builder.Services.AddDbContext<EmployeeDbContext>(op =>op.UseMySql(conString, ServerVersion.AutoDetect(conString)));
builder.Services.AddDbContext<ClientDbContext>(op => op.UseMySql(conString, ServerVersion.AutoDetect(conString)));
builder.Services.AddDbContext<MessengerDbContext>(op => op.UseMySql(conString, ServerVersion.AutoDetect(conString)));
builder.Services.AddDbContext<RbacDbContext>(op => op.UseMySql(conString, ServerVersion.AutoDetect(conString)));
builder.Services.AddDbContext<ComapanyProjectDbContext>(op=>op.UseMySql(conString, ServerVersion.AutoDetect(conString)));
builder.Services.AddDbContext<PostJobDbcontext>(op => op.UseMySql(conString, ServerVersion.AutoDetect(conString)));
builder.Services.AddDbContext<ProjectsDbContext>(op => op.UseMySql(conString, ServerVersion.AutoDetect(conString)));
builder.Services.AddDbContext<ProjectDbContext>(op => op.UseMySql(conString, ServerVersion.AutoDetect(conString)));
builder.Services.AddScoped<JwtHelper>();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// Apply CORS Middleware before Authorization
app.UseCors(MyAllowSpecificOrigins);

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
